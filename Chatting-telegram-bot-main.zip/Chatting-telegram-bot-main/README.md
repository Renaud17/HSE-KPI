# Chatting-telegram-bot

## Telegram bot chats on different topics thanks to machine learning

### Описание:
Телеграм бот-болталка на базе ИИ, демо-версия датасета

### Технологии:
- Python
- telegram
- sklearn (TfidfVectorizer, LinearSVC)
- nltk (edit_distance)
- random




